# XnGine Full Decompilation

## Overview
This directory contains the complete decompilation of FALL.EXE from Daggerfall.

## Statistics
- Total Functions: 2415
- Categories: 2

## File Organization

### Header Files
- `xngine_full.h` - All function prototypes

### Source Files (by category)
- `xngine_system.c` - 1 functions
- `xngine_unknown.c` - 2414 functions

## Function Categories

- **rendering**: 0 functions
- **memory**: 0 functions
- **world**: 0 functions
- **file_io**: 0 functions
- **audio**: 0 functions
- **ai**: 0 functions
- **ui**: 0 functions
- **math**: 0 functions
- **string**: 0 functions
- **system**: 1 functions
- **unknown**: 2414 functions

## Usage

This is decompiled code from a binary. It represents the logic and structure
of the original XnGine, but:

1. Variable names are generic (var1, var2, etc.)
2. Some low-level operations may not translate perfectly
3. This is for educational/research purposes only

## Building

This code is not directly compilable without significant work:
- You would need to implement all low-level DOS/WATCOM-specific functions
- Link against appropriate libraries
- Handle all assembly-specific operations

However, it provides a complete blueprint of how the engine works.

/*
 * ============================================================================
 * XnGine Decompilation - SYSTEM Subsystem
 * ============================================================================
 * 
 * Total Functions: 1
 * Category: system
 */

#include "xngine_full.h"


// ============================================================================
// Function: entry0
// Address: 0x9ac3c
// Size: 716 bytes
// ============================================================================

int entry0 (int esi, int edx) {
    loc_0x9ac3c:
        goto loc_0x9acb4
         // do {
    loc_0x9acb4:
        // CODE XREF from entry0 @ 0x9ac3c
        st
        esp &= 0xfffffffc // ebp
        ebx = esp     // ebp
        dword [0x19738] = ebx // [0x19738:4]=0x16cde8// RELOC 32
        dword [0x19724] = ebx // [0x19724:4]=0x458bffff// RELOC 32
        ax = 0x24     // '$' // 36
        word [0x19730] = ax // [0x19730:2]=0xfe4// RELOC 32
        ebx = 0x50484152 // 'RAHP'
        eax -= eax
        ah = 0x30     // '0' // 48
        int 0x21      // 33 = unknown ()
        byte [0x1975b] = al // [0x1975b:1]=15// RELOC 32
        byte [0x1975c] = ah // [0x1975c:1]=191// RELOC 32
        ecx = eax
        // CODE XREF from entry0 @ +0x41
        esi -= esi
        // CODE XREF from entry0 @ +0x3e
        edi = 0x81    // 129
        eax >>>= 0x10
        var = ax - 0x4458
        if  (var) goto loc_0x9ad36 // likely
         // } while (?);
        }
        return eax;
    loc_0x9acf8:
        // CODE XREF from entry0 @ +0x4a
        bl -= 0x30    // 48
        al = bl
        ah = 0
        push  (eax)
        es = word [0x19730] // [0x19730:2]=36// RELOC 32
        ebx = dword es:[0x5c]
        ebx += 0xfff
        ebx &= 0xfffff000
        dword [0x19724] = ebx // [0x19724:4]=0x10078000 ebp// RELOC 32
        ebx >>>= 0xc
        ax = ds
        es = eax
        ah = 0x4a     // 'J' // 74
        int 0x21      // 33 = unknown ()
        eax = pop  () // ebp
        bx = ds
        cx = 0x2c     // ',' // 44
        goto loc_0x9ad6e
         // do {
    loc_0x9ad6e:
        // CODE XREF from entry0 @ 0x9ad34
        goto loc_0x9adc9
         // } while (?);
        }
        return eax;
    loc_0x0009ad36: // orphan
             // CODE XREF from entry0 @ 0x9acf6
             var = ax - 0x4243
             if  (var) goto loc_0x9ad70 // likely

    loc_0x0009ad3c: // orphan
         dword [0x18d70] = edx    // [0x18d70:4]=0xeb027438// RELOC 32 
         esi = edx
         edx = dword [esi + 0x1c]
         ebx = esp                // ebp
         ebx -= edx
         ah = 0x4a                // 'J' // 74
         int 0x21                 // 33 = unknown ()
         bx = ds
         word [0x19730] = ds      // [0x19730:2]=36// RELOC 32 
         eax = dword [esi + 0x10]
         edi += eax
         esi -= esi
         si = word [eax + 0x2c]
         esi <<<= 4
         cx = ds
         al = 9
         ah = 0

    loc_0x0009ad70: // orphan
         // CODE XREF from entry0 @ 0x9ad3a
         dx = 0x78                // 'x' // 120
         ax = 0xff00
         int 0x21                 // 33 = unknown ()
         var = al - 0
         if  (!var) goto loc_0x9adb2 // likely

    loc_0x0009ad7e: // orphan
         ax = gs
         var = ax - 0
         if  (!var) goto loc_0x9ad8d // likely

    loc_0x0009ad87: // orphan
         word [0x18d74] = ax      // [0x18d74:2]=0x8306// RELOC 32 

    loc_0x0009ad8d: // orphan
         // CODE XREF from entry0 @ 0x9ad85
         ax = 6
         bx = ds
         int 0x31                 // 49 = unknown ()
         al = 1
         ah = 0
         dx |= cx
         if  (!var) goto loc_0x9ada1 // likely

    loc_0x0009ad9f: // orphan
         ah = 1

    loc_0x0009ada1: // orphan
         // CODE XREF from entry0 @ 0x9ad9d
         word [0x19730] = es      // [0x19730:2]=36// RELOC 32 
         cx = word es:[0x2c]
         goto loc_0x9adc9

    loc_0x0009adb2: // orphan
         // CODE XREF from entry0 @ 0x9ad7c
         dx = ds
         cx = 0x24                // '$' // 36
         ds = ecx
         cx = 0x2c                // ',' // 44
         ds = edx
         bx = 0x17                // 23
         al = 0
         ah = 0

    loc_0x0009adc9: // orphan
         // CODE XREFS from entry0 @ 0x9ad6e, 0x9adb0
         byte [0x19752] = al      // [0x19752:1]=15// RELOC 32 
         byte [0x19753] = ah      // [0x19753:1]=133// RELOC 32 
         es = ebx
         word es:[0x8af11] = ds   // RELOC 32 
         dword [0x19755] = esi    // [0x19755:4]=0x8b000011// RELOC 32 
         word [0x19759] = cx      // [0x19759:2]=0xe455// RELOC 32 
         push  (esi)
         es = word [0x19730]      // [0x19730:2]=36// RELOC 32 
         edx = 0x3d668            // RELOC 32 
         edx += 0xf               // 15
         dl &= 0xf0               // 240
         ecx -= ecx
         cl = byte es:[edi - 1]
         cl
         al = 0x20                // 32
         repe scasb al,yte es:[edi]
         esi = edi - 1
         edi = edx
         bx = es
         dx = ds
         ds = ebx
         es = edx
         if  (!var) goto loc_0x9ae1e // likely

    loc_0x0009ae1b: // orphan
         ecx+
         rep movsb byte es:[edi],yte ptr [esi]

    loc_0x0009ae1e: // orphan
         // CODE XREF from entry0 @ 0x9ae19
         al -= al
         stosb byte es:[edi],l
         stosb byte es:[edi],l
         esi = pop  ()
         edi-
         push  (edi)              // ebp
         push  (edx)
         ds = word es:[0x19759]   // RELOC 32 
         ebp -= ebp

    loc_0x0009ae30: // orphan
         // CODE XREF from entry0 @ 0x9ae4e
         eax = dword [esi]
         eax |= 0x20202020
         var = eax - 0x37386f6e
         if  (var) goto loc_0x9ae45 // likely

    loc_0x0009ae3e: // orphan
         var = byte [esi + 4] - 0x3d
         if  (var) goto loc_0x9ae45 // likely

    loc_0x0009ae44: // orphan
         ebp+

    loc_0x0009ae45: // orphan
         // CODE XREFS from entry0 @ 0x9ae3c, 0x9ae42, 0x9ae49
         var = byte [esi] - 0
         lodsb al,yte [esi]
         if  (var) goto loc_0x9ae45 // unlikely

    loc_0x0009ae4b: // orphan
         var = byte [esi] - 0
         if  (var) goto loc_0x9ae30 // unlikely

    loc_0x0009ae50: // orphan
         lodsb al,yte [esi]
         esi+
         esi+

    loc_0x0009ae53: // orphan
         // CODE XREF from entry0 @ 0x9ae57
         var = byte [esi] - 0
         movsb byte es:[edi],yte ptr [esi]
         if  (var) goto loc_0x9ae53 // unlikely

    loc_0x0009ae59: // orphan
         ds = pop  ()
         esi = pop  ()
         ebx = esp
         word [0x19750] = bp      // [0x19750:2]=0x2b0// RELOC 32 
         dword [0x19734] = edi    // [0x19734:4]=0xe4458b1f// RELOC 32 
         dword [0x19720] = ebx    // [0x19720:4]=0xffffba0d// RELOC 32 
         ecx = 0x3d668            // RELOC 32 
         edi = 0x1df74            // RELOC 32 
         ecx -= edi
         var = byte [0x19752] - 1 // [0x19752:1]=0// RELOC 32 
         if  (var) goto loc_0x9ae94 // likely

    loc_0x0009ae87: // orphan
         var = ecx - 0x1000
         if  (((unsigned) var) <= 0) goto 0x9ae94 // likely

    loc_0x0009ae8f: // orphan
         ecx = 0x1000

    loc_0x0009ae94: // orphan
         // CODE XREFS from entry0 @ 0x9ae85, 0x9ae8d
         dl = cl
         ecx >>>= 2
         eax -= eax
         rep stosd dword es:[edi],ax
         cl = dl
         cl &= 3
         rep stosb byte es:[edi],l
         eax = 0x3d668            // RELOC 32 
         eax += 0xf               // 15
         al &= 0xf0               // 240
         dword [0x19728] = eax    // [0x19728:4]=0x1631e8e4// RELOC 32 
         dword [0x1972c] = esi    // [0x1972c:4]=0x458b0000// RELOC 32 
         eax = 0xff               // 255
         fcn.000a06f4  ()
         ebp -= ebp
         fcn.000a06a4  ()

    loc_0x0009aecb: // orphan
         // CODE XREF from fcn.0009a8b1 @ 0x9a8c2
         goto loc_0x9aef0

    loc_0x0009aef0: // orphan
         // CODE XREF from entry0 @ 0x9aecb
         push  (eax)
         eax = 0
         edx = 0xff               // 255
         fcn.000a073f  ()
         eax = pop  ()
         ah = 0x4c                // 'L' // 76
         int 0x21                 // 33 = unknown ()
         eax = eax

}



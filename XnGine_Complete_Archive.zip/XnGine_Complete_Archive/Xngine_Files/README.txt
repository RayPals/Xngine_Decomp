DAGGERFALL XNGINE FILES
========================
Extracted from Daggerfall Demo

CORE ENGINE FILES:
------------------
FALL.EXE (1.8 MB)
  - Main Xngine executable
  - The game engine that powers Daggerfall
  - DOS protected mode executable

SOUND SYSTEM DRIVERS:
---------------------
HMIDET.386 (82 KB)
  - HMI Sound System detection driver
  
HMIDRV.386 (310 KB)
  - HMI Sound System primary driver
  
HMIMDRV.386 (116 KB)
  - HMI Sound System MIDI driver

CONFIGURATION FILES:
--------------------
Z.CFG
  - Main game configuration file
  
HMISET.CFG
  - HMI sound system configuration
  
CASTER.CFG
  - Spell casting configuration

ENGINE DATA FILES (.DAT):
-------------------------
MASTER.DAT - Master index file
BIO.DAT - Biography/character data
CLASSES.DAT - Character class definitions
COPYFILE.DAT - Copy protection data
COUNT.DAT - Count/statistics data
HAL.DAT - Hardware abstraction layer data
LIGHT.DAT - Lighting system data
MENUFONT.DAT - Menu font data
NAMEGEN.DAT - Name generation data
PAINT.DAT - Paint/texture system data
RUMOR.DAT - Rumor system data
SKYPAL.DAT - Sky palette data
VERSTR.DAT - Version string data

COLOR PALETTE FILES (.COL):
---------------------------
DAGGER.COL - Main Daggerfall color palette
ART_PAL.COL - Art palette
DANKBMAP.COL - Dungeon/dark bitmap palette
FMAP_PAL.COL - Full map palette
NIGHTSKY.COL - Night sky palette

PALETTE FILES (.PAL):
--------------------
MAP.PAL - Map palette
OLDMAP.PAL - Legacy map palette
OLDPAL.PAL - Legacy palette
PAL.PAL - Primary palette

LIGHTING FILES (.LGT):
---------------------
DARKEN.LGT - Darkening light map
DARKENA.LGT - Alternative darkening light map
RAIN.LGT - Rain lighting effects

NOTES:
------
The Xngine was Bethesda's proprietary game engine used for The Elder Scrolls II: Daggerfall.
It featured advanced capabilities for its time including:
- True 3D rendering
- Large procedurally generated world
- Complex quest system
- Advanced AI and NPC scheduling
- Dynamic weather and lighting

These files represent the core engine components needed to run the Daggerfall demo.
